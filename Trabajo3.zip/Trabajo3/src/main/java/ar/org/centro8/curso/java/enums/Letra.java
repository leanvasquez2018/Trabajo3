package ar.org.centro8.curso.java.enums;

public enum Letra {
    A,
    B,
    C
}
